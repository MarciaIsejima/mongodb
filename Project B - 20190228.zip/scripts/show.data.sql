use chatapp;

select * from users;
select * from user_roles;
select * from user_addresses;
